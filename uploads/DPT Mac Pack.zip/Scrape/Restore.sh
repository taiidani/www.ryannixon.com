#!/usr/bin/env bash

serverPath=`pwd`
restoreTarget=/Users/

if [ $# -eq 0 ]; then
	echo "Usage: Restore OLDNAME NEWNAME"
	echo "Used for restoring user data from archived home directories."
	echo "Example: Restore designpt dpt"
	echo "  OLDNAME\tThe filename of the disk image for this user's old home folder."
	echo "  NEWNAME\tThe name of the new home folder for this user."
	exit 0
fi

cd $serverPath

if [ ! -r $1.dmg ]; then
	echo "Error: Supplied source is not readable."
	exit 1
fi

if [ ! -d $restoreTarget/$2 ]; then
	echo "Error: Target home directory does not exist."
	exit 1
fi

if [ ! -r $restoreTarget/$2/Desktop ]; then
	echo "Error: Cannot read user's home directory (did you use sudo?)."
	exit 1
fi

hdiutil attach -quiet -readonly -nobrowse -mountpoint tmp $1.dmg

#Restoring files
rsync -rlv --size-only --exclude=Library/ --exclude=.* tmp/ $restoreTarget/$2/

#Restoring Safari Bookmarks
if [ -r tmp/Library/Safari/Bookmarks.plist ]; then
	install tmp/Library/Safari/Bookmarks.plist $restoreTarget/$2/Library/Safari/Bookmarks.plist
fi

hdiutil detach -quiet tmp

echo "Completed restoring user $2's data.\n"