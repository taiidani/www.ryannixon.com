#!/usr/bin/env bash

serverPath=/Volumes/Media
scrapeTarget=/Users/

# if [ $# -eq 0 ]; then
# 	echo "Used for archiving entire directories. This will take all directory items at the path in the first argument and create disk images out of them."
# 	exit 0
# fi
# 
# if [ ! -d $1 ]; then
# 	echo "Error: Supplied source path is not a directory."
# 	exit 1
# fi

cd $scrapeTarget

for dirName in `ls`; do
	if [ -d $dirName ]; then
		hdiutil create -srcfolder $dirName $serverPath/$dirName.dmg
	fi
done

system_profiler -xml -detailLevel full > $serverPath/$HOSTNAME.spx