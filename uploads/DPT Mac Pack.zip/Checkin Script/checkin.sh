#!/usr/bin/env bash
#
# @name Design-PT Macintosh Checkin Script
# @author Ryan Nixon
# @version 1.0
#
# Every 3 hours launchd will call this script. It will first attempt to update itself,
# then will proceed to update each item that it has been programmed to track.
# 
# This is the script's basic functionality:
# 	1) Send a call to the server, downloading a new copy of itself. If the new copy is unavailable it will exit.
# 	2) Create all directories and manifest files if they don't already exist.
# 	3) Send a full copy of all current manifest files to the server. The server will respond with an
#		xml-tag separated list of all updates that need attention
#	4) For each item in the list, the script will download a new copy of the item. It will also call the
#		type-specific function for that item. The type-specific function should deploy the new copy into the system.
# 
# **WARNING**
# If you would like to update the launchd entry for this script directly, you will have to have the client reboot
# their computer before the script takes effect. The suggested method is more roundabout. Create a new launchd
# item that will upon load use launchctl to reload the plist file for this script, then delete itself.
#
# To add new functionality to this script you will have to add the following items:
# 	1) Create the appropriate lines to create the local directory and manifest for this item BEFORE the
#		call to the server.
#	2) In the call to the server, add a new entry for your manifest (eg. '-F "type/type.manifest"').
#	3) Add another function and function call below the updateManifest function definition. In this
#		function you can place entry-specific logic for each file that gets downloaded.
#		**Make sure that you place this with the other functions in an order that is appropriate for the type!!
# 

updateURL=http://update.taiidani.com/MacPack
launchdJob=com.dpt.macpack.checkin

#Change working directory and start logging
cd /Library/Application\ Support/DPT
mkdir -p -m 755 /Library/Logs/DPT
touch /Library/Logs/DPT/startup.log
date

#Update Self
curl -sfO $updateURL/checkin.sh

if [[ $? -eq 22 ]]; then
	echo "Error: Could not locate checkin.sh on server. This checkin script may be out of date."
	exit 1
fi

#Variables
updated=0

#Begin updating
echo "Checking for updates at $updateURL"

#Create initial directories & manifests
mkdir -p -m 755 binaries
touch binaries/binaries.manifest

mkdir -p -m 755 scripts
touch scripts/scripts.manifest

mkdir -p -m 755 defaultPreferences
touch defaultPreferences/defaultPreferences.manifest

mkdir -p -m 755 applications
touch applications/applications.manifest

mkdir -p -m 755 launchd
touch launchd/launchd.manifest

#Send full manifest list to the server
response=`curl -sf -F "launchd=@launchd/launchd.manifest" -F "binaries=@binaries/binaries.manifest" \
 	-F "scripts=@scripts/scripts.manifest" -F "defaultPreferences=@defaultPreferences/defaultPreferences.manifest" \
	-F "applications=@applications/applications.manifest" $updateURL/server/checkin.php`

if [[ $? -eq 22 ]]; then
	echo "Error: Unable to reach update server."
	exit 1
fi

#Define updating function for later use
# $1 -	This is the type.
#		It defines what tag to look for, as well as the filename and directory of the manifest.
#		It also is the name of the function that will be called (prefixed with _) for specific actions taken on the type entries.
#		In other words, Don't Get This Wrong!
# $2 - This is the human readable name for the type. It will be output to stdout if updates are found.
function updateManifest() {
	echo $response | fgrep -q "<$1>"

	if [ $? -eq 0 ]; then
		echo "Found updates for $2"
		updated=1
		cd $1

		parsing=0
		
		#For each line in the server's response
		for filename in $response; do
			if [ $filename = "</$1>" ]; then
				#Stop parsing
				parsing=0
			fi
	
			#This statement only executes between the <type> tags
			if [ $parsing -eq 1 ]; then
				curl -sfO $updateURL/$1/$filename
				
				if [ $? -eq 22 ]; then
					echo "Error: Failed to retrieve $filename"
					exit 2
				fi

				#Call the item-specific function
				_$1 $filename

				echo $filename
			fi
	
			if [ $filename = "<$1>" ]; then
				#Begin parsing on next run
				parsing=1
			fi
		done

		curl -sfO $updateURL/$1/$1.manifest
		
		if [ $? -eq 22 ]; then
			echo "Error: Failed to update $2 manifest"
		fi
		
		cd ..
	fi
}


#Update Unix Applications (Binaries)
function _binaries() {
	cp -f $1 /usr/sbin/
	chmod 555 /usr/sbin/$1
}
updateManifest binaries Binaries


#Update Scripts
function _scripts() {
	chmod 755 $1
}
updateManifest scripts Scripts


#Update Default Preferences
function _defaultPreferences() {
	cp -f $1 /Library/Preferences/
	chmod 644 /Library/Preferences/$1
}
updateManifest defaultPreferences "Default Preferences"


#Update Applications
function _applications() {
	unzip -oqq $1 -d /Applications/
}
updateManifest applications Applications


#Update LaunchDaemons
function _launchd() {
	jobName=`echo $1 | sed s/".plist"//g`

	cp -f $1 /Library/LaunchDaemons/
	chmod 644 /Library/LaunchDaemons/$1
	
	launchctl list | fgrep -q "$jobName"
	jobRunning=$?
	
	if [ $jobName = $launchdJob ]; then
		echo "Warning: You are updating the job that is currently running this script"
		echo "This upgrade will not be performed until the next reboot"
	elif [ $jobRunning -eq 0 ]; then
		launchctl unload /Library/LaunchDaemons/$1
	fi
	
	launchctl load /Library/LaunchDaemons/$1 >& /dev/null
}
updateManifest launchd LaunchDaemons


#Output the results to stdout
if [ $updated -eq 0 ]; then
	echo No new updates found
else
	echo Update complete
fi

exit 0