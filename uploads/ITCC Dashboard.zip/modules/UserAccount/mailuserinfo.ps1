﻿$adUser = "cn=axjw,ou=AD_Admins,dc=uaa,dc=alaska,dc=edu"
$sunUser = "uid=axjw,ou=Admin,o=uaa.alaska.edu,o=isp"
$pass = ""

[Reflection.Assembly]::LoadFile("C:\exenable\Novell.Directory.Ldap.dll") | out-null


if ($args[0] -eq $null)	{
	Write-Host 	""
				"No User Specified!!"
				"";
	exit
	}

#find stuff in SUN
#
$ldap = new-object Novell.Directory.Ldap.LdapConnection
$ldap.connect("sentry.uaa.alaska.edu", "389")
$ldap.bind($sunUser, $pass)

$modifiedUserName = $args[0]

$ldapUser = $ldap.read("uid=" + $modifiedUserName + ",ou=Admin,o=uaa.alaska.edu,o=isp")

$mailForwardingAddress = $ldapUser.getAttribute("mailForwardingAddress").stringValue
$mailDeliveryOption = $ldapUser.getAttribute("mailDeliveryOption").stringValue

"mailForwardingAddress  =   " + $mailForwardingAddress
"*mailDeliveryOption     =   " + $mailDeliveryOption

#find stuff in AD
#
$searcher = New-Object system.DirectoryServices.DirectorySearcher
$searcher.filter = "(&(objectClass=user)(sAMAccountName=" + $modifiedUserName + "))"
$results = $searcher.findall()

$dsUser = New-Object system.DirectoryServices.DirectoryEntry($results[0].path)

if ($dsUser.homeMDB -ne $null)	{
	"*User is Exchange Enabled"
}
else	{
	"*User is NOT Exchange Enabled"
}
