﻿#
# Exchange Enable helper script
# dependancies: interop.cdoexm.dll
# ***THIS MUST BE RUN ON A MACHINE WITH THE EXCHANGE SYSTEM MANAGER INSTALLED***
# ***DO NOT ATTEMPT TO MANUALLY REGISTER THE DLL(S), YOU WILL REGRET IT***
#
# this script does the M$ dirty work for the PHP
#
# Return codes:
# 0 - Success
#




function getMailStore()
{
	$rand = New-Object system.Random

	switch ($rand.next(1,12))	{
		1 	{return "CN=SG1-M1,CN=SG1," + $EXCHANGE_INFOSTORE}
		2	{return "CN=SG1-M2,CN=SG1," + $EXCHANGE_INFOSTORE}
		3	{return "CN=SG1-M3,CN=SG1," + $EXCHANGE_INFOSTORE}
		4	{return "CN=SG1-M4,CN=SG1," + $EXCHANGE_INFOSTORE}
		5	{return "CN=SG2-M1,CN=SG2," + $EXCHANGE_INFOSTORE} 
		6	{return "CN=SG2-M2,CN=SG2," + $EXCHANGE_INFOSTORE}
		7	{return "CN=SG2-M3,CN=SG2," + $EXCHANGE_INFOSTORE}
		8	{return "CN=SG2-M4,CN=SG2," + $EXCHANGE_INFOSTORE}
		9	{return "CN=SG3-M1,CN=SG3," + $EXCHANGE_INFOSTORE}
		10	{return "CN=SG3-M2,CN=SG3," + $EXCHANGE_INFOSTORE} 
		11	{return "CN=SG3-M3,CN=SG3," + $EXCHANGE_INFOSTORE}
		12	{return "CN=SG3-M4,CN=SG3," + $EXCHANGE_INFOSTORE}
	
		default {return "CN=SG1-M1,CN=SG1," + $EXCHANGE_INFOSTORE}
		
	}
}

$LDAP		= "LDAP://isis.uaa.alaska.edu:389"
$LDAP_USER	= "exenable" 
$LDAP_PASS	= ""	

$EXCHANGE_INFOSTORE =  "CN=InformationStore,CN=ancexchange,CN=Servers,CN=UAA Main Group,CN=Administrative Groups,CN=UaaExch,CN=Microsoft Exchange,CN=Services,CN=Configuration,dc=uaa,dc=alaska,dc=edu";

$ASSEMBLY      = [Reflection.Assembly]::LoadFile("C:\WINDOWS\system32\Interop.CDOEXM.dll")
$ASSEMBLY_TYPE = $ASSEMBLY.GetType("CDOEXM.IMailboxStore")
$BINDING_FLAGS = [Reflection.BindingFlags] "invokemethod,public"

if ($args[0] -eq $null)	{
	Write-Host 	""
				"Usage: script.ps1 <sAMAccountName>"
				"";
	exit
	}
	
$searcher = New-Object system.DirectoryServices.DirectorySearcher

#the following line is only needed the script is being run by a restricted user
$searcher.searchroot = New-Object system.DirectoryServices.DirectoryEntry($LDAP, $LDAP_USER, $LDAP_PASS)

$searcher.filter = "(&(objectclass=user)(sAMAccountName=" + $args[0] + "))"
$user = $searcher.findall()

$dsuser = new-object system.directoryservices.directoryentry($user[0].path)

if ($dsuser.sAMAccountName -eq $null)	{
	Write-Host "User does not exist in AD"
	exit
	}

if ($dsuser.homeMDB -ne "")	{
	Write-Host $dsuser.sAMAccountName is already Exchange enabled
	exit
	}


$ASSEMBLY_TYPE.invokemember("createmailbox",$BINDING_FLAGS,$null,$dsuser.psbase.nativeobject,(getMailStore))

$dsuser.psbase.commitchanges()

#we have to wait for a minute or two for the mailbox to become available
#since it's kinda dificult to do with php I'm doing the waiting here
#$current_date = date
#$time = $current_date.minute

#$exit_time = [int] $time + 2

#if ($exit_time -gt 59)	{
#	$exit_time = 02
#	}
	
#while ($exit_time -ne $time)	{
#	$current_date = date
#	$time = $current_date.minute
#	}
	

"0" #Write-Host "Success"
   
#todo: destroy stuff (fuck it it's powershell who really needs destructors anyway)
   