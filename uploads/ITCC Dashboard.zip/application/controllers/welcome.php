<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function index()
	{
		$this->smartyparser->display('index.tpl');
	}
	
}

?>