<?php

function render($templateName = null, array $data = null) {
	if(is_null($templateName)) return renderDefault($data);
	
	$CI =& get_instance();
	if(!is_null($data)) $CI->smartyparser->assign($data);
	
	$CI->smartyparser->display($templateName);
}

function renderDefault($data = null) {
	$CI =& get_instance();
	
	if(!is_null($data)) {
		if(is_array($data)) $CI->smartyparser->assign($data);
		else $CI->smartyparser->assign('content', $data);
	}
	$CI->smartyparser->display('empty.tpl');
}

function renderError($content = null, $returnURL = null, Exception $e = null) {
	$CI =& get_instance();
	
	if(!is_null($content)) $CI->smartyparser->assign('content', $content);
	if(!is_null($returnURL)) $CI->smartyparser->assign('returnURL', $returnURL);
	if(!is_null($e)) $CI->smartyparser->assign('e', $e);

	$CI->smartyparser->display('error.tpl');
}

?>