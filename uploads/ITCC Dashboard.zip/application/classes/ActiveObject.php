<?php


/**
 * The base class for all Active Objects. Maintains a list of constants defining which
 * types of Active Objects are allowed. Modules may use this list to enforce type
 * requirements when retrieving their Active Objects.
 **/
abstract class ActiveObject {
	const USER = "AOUser";
	const COURSE = "AOCourse";
	
	public $id;
	public $url;
	public $name;
	
	abstract public static function restoreFromSession();
	abstract public function saveToSession();
}

?>