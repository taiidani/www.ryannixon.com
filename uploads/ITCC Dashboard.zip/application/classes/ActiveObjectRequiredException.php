<?php

class ActiveObjectRequiredException extends Exception {
	protected $message = "This page requires an active object to be set before use. Please search for a user or course before accessing this page.";


}

?>