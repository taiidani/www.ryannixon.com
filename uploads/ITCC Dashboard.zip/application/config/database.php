<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the "Database Connection"
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database type. ie: mysql.  Currently supported:
				 mysql, mysqli, postgre, odbc, mssql, sqlite, oci8
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Active Record class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the "default" group).
|
| The $active_record variables lets you determine whether or not to load
| the active record class
*/

$active_group = "default";
$active_record = FALSE;

$db['default']['hostname'] = "anc-vsql01.uaa.alaska.edu\ANCVSQL01";
$db['default']['username'] = "callcenterweb";
$db['default']['password'] = "";
$db['default']['database'] = "devcallcenter";
$db['default']['dbdriver'] = "sqlsrv";
$db['default']['dbprefix'] = "";
$db['default']['pconnect'] = TRUE;
$db['default']['db_debug'] = TRUE;
$db['default']['cache_on'] = FALSE;
$db['default']['cachedir'] = "";
$db['default']['char_set'] = "utf8";
$db['default']['dbcollat'] = "utf8_general_ci";
$db['default']['swap_pre'] = '';
$db['default']['autoinit'] = TRUE;
$db['default']['stricton'] = FALSE;

$db['blackboard']['hostname'] = "anc-vsql02.uaa.alaska.edu\ANCVSQL02";
$db['blackboard']['username'] = "axhelp";
$db['blackboard']['password'] = "";
$db['blackboard']['database'] = "bb_bb60";
$db['blackboard']['dbdriver'] = "sqlsrv";
$db['blackboard']['dbprefix'] = "";
$db['blackboard']['pconnect'] = TRUE;
$db['blackboard']['db_debug'] = TRUE;
$db['blackboard']['cache_on'] = FALSE;
$db['blackboard']['cachedir'] = "";
$db['blackboard']['char_set'] = "utf8";
$db['blackboard']['dbcollat'] = "utf8_general_ci";
$db['default']['swap_pre'] = '';
$db['default']['autoinit'] = TRUE;
$db['default']['stricton'] = FALSE;

$db['cms']['hostname'] = "anc-vsql01.uaa.alaska.edu\ANCVSQL01";
$db['cms']['username'] = "axhelp";
$db['cms']['password'] = "";
$db['cms']['database'] = "cms-site-www";
$db['cms']['dbdriver'] = "sqlsrv";
$db['cms']['dbprefix'] = "";
$db['cms']['pconnect'] = TRUE;
$db['cms']['db_debug'] = TRUE;
$db['cms']['cache_on'] = FALSE;
$db['cms']['cachedir'] = "";
$db['cms']['char_set'] = "utf8";
$db['cms']['dbcollat'] = "utf8_general_ci";
$db['default']['swap_pre'] = '';
$db['default']['autoinit'] = TRUE;
$db['default']['stricton'] = FALSE;


$db['cmsdata']['hostname'] = "anc-vsql01.uaa.alaska.edu\ANCVSQL01";
$db['cmsdata']['username'] = "axhelp";
$db['cmsdata']['password'] = "";
$db['cmsdata']['database'] = "cms-data-views";
$db['cmsdata']['dbdriver'] = "sqlsrv";
$db['cmsdata']['dbprefix'] = "";
$db['cmsdata']['pconnect'] = TRUE;
$db['cmsdata']['db_debug'] = TRUE;
$db['cmsdata']['cache_on'] = FALSE;
$db['cmsdata']['cachedir'] = "";
$db['cmsdata']['char_set'] = "utf8";
$db['cmsdata']['dbcollat'] = "utf8_general_ci";
$db['default']['swap_pre'] = '';
$db['default']['autoinit'] = TRUE;
$db['default']['stricton'] = FALSE;


/* End of file database.php */
/* Location: ./system/application/config/database.php */