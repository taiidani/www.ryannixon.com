<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| SunOne LDAP
|--------------------------------------------------------------------------
*/
$config['sunone']['SERVER']		= "sentry.uaa.alaska.edu";
$config['sunone']['USER']		= "uid=elmo,ou=admin,o=uaa.alaska.edu,o=isp";
$config['sunone']['BASE']		= "o=uaa.alaska.edu,o=isp";
$config['sunone']['PASS']		= "";
$config['sunone']['PORT']		= "389";


/*
|--------------------------------------------------------------------------
| Federated LDAP
|--------------------------------------------------------------------------
*/
$config['federated']['SERVER']	= "ldaps://anc-adua01.ua.ad.alaska.edu";
$config['federated']['USER']	= "cn=axhelp,ou=userAccounts,ou=uaa,dc=ua,dc=ad,dc=Alaska,dc=edu";
$config['federated']['BASE']	= "DC=UA,DC=AD,DC=ALASKA,DC=EDU";
$config['federated']['PASS']	= "";
$config['federated']['PORT']	= "636";


/*
|--------------------------------------------------------------------------
| Active Directory
|--------------------------------------------------------------------------
*/
//$config['ad']['SERVER']	= "uaa-dc01.uaa.alaska.edu";
$config['ad']['SERVER']	= "LDAPS://isis.uaa.alaska.edu/";
$config['ad']['USER']	= "cn=elmo,ou=ad_admins,dc=uaa,dc=Alaska,dc=edu";
$config['ad']['BASE']	= "DC=uaa,DC=alaska,DC=edu";
$config['ad']['PASS']	= "";
$config['ad']['PORT']	= "636";


/*
|--------------------------------------------------------------------------
| Blackboard
|--------------------------------------------------------------------------
*/
$config['blackboard']['SERVER']	= "anc-vsql02.uaa.alaska.edu\ANCVSQL02";


/*
|--------------------------------------------------------------------------
| Google Apps
|--------------------------------------------------------------------------
*/
$config['google']['EMAIL']			= "jdwatson@alaska.edu";
$config['google']['PASS']			= "";
$config['google']['DOMAIN']			= "alaska.edu";
$config['google']['DEFAULTPASS']	= '';

$config['roxen']['USER'] = "googleOptInUAA";
$config['roxen']['PASS'] = "";


/* End of file auth.php */
/* Location: ./system/application/config/auth.php */