<?php /* Smarty version Smarty-3.0.6, created on 2011-04-12 22:28:19
         compiled from "/itcc-dashboard/application/views\searchLDAP.tpl" */ ?>
<?php /*%%SmartyHeaderCode:152764da542834c47e9-85471733%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '00b6c838d244027f6efe8edc5bc3c365ccd9fd7d' => 
    array (
      0 => '/itcc-dashboard/application/views\\searchLDAP.tpl',
      1 => 1302561261,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '152764da542834c47e9-85471733',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_smarty_tpl->getVariable('info')->value['count']==0){?>No results.
<?php }else{ ?>
	<table class='searchResults striped'>
		<thead>
			<tr>
				<th>Username(s)</th>
				<th>UAID</th>
				<th>Full Name</th>
				<th>Global ID</th>
				
			</tr>
		<tbody>
		<?php $_smarty_tpl->tpl_vars['x'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['x']->step = 1;$_smarty_tpl->tpl_vars['x']->total = (int)ceil(($_smarty_tpl->tpl_vars['x']->step > 0 ? $_smarty_tpl->getVariable('info')->value['count']-1+1 - (0) : 0-($_smarty_tpl->getVariable('info')->value['count']-1)+1)/abs($_smarty_tpl->tpl_vars['x']->step));
if ($_smarty_tpl->tpl_vars['x']->total > 0){
for ($_smarty_tpl->tpl_vars['x']->value = 0, $_smarty_tpl->tpl_vars['x']->iteration = 1;$_smarty_tpl->tpl_vars['x']->iteration <= $_smarty_tpl->tpl_vars['x']->total;$_smarty_tpl->tpl_vars['x']->value += $_smarty_tpl->tpl_vars['x']->step, $_smarty_tpl->tpl_vars['x']->iteration++){
$_smarty_tpl->tpl_vars['x']->first = $_smarty_tpl->tpl_vars['x']->iteration == 1;$_smarty_tpl->tpl_vars['x']->last = $_smarty_tpl->tpl_vars['x']->iteration == $_smarty_tpl->tpl_vars['x']->total;?>
			<tr>
				<td>
					<?php if (isset($_smarty_tpl->getVariable('info',null,true,false)->value[$_smarty_tpl->getVariable('x',null,true,false)->value]['uid'])){?>
						<?php $_smarty_tpl->tpl_vars['y'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['y']->step = 1;$_smarty_tpl->tpl_vars['y']->total = (int)ceil(($_smarty_tpl->tpl_vars['y']->step > 0 ? $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uid']['count']-1+1 - (0) : 0-($_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uid']['count']-1)+1)/abs($_smarty_tpl->tpl_vars['y']->step));
if ($_smarty_tpl->tpl_vars['y']->total > 0){
for ($_smarty_tpl->tpl_vars['y']->value = 0, $_smarty_tpl->tpl_vars['y']->iteration = 1;$_smarty_tpl->tpl_vars['y']->iteration <= $_smarty_tpl->tpl_vars['y']->total;$_smarty_tpl->tpl_vars['y']->value += $_smarty_tpl->tpl_vars['y']->step, $_smarty_tpl->tpl_vars['y']->iteration++){
$_smarty_tpl->tpl_vars['y']->first = $_smarty_tpl->tpl_vars['y']->iteration == 1;$_smarty_tpl->tpl_vars['y']->last = $_smarty_tpl->tpl_vars['y']->iteration == $_smarty_tpl->tpl_vars['y']->total;?>
							<a href='/user/info/<?php echo $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uid'][$_smarty_tpl->getVariable('y')->value];?>
'><?php echo $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uid'][$_smarty_tpl->getVariable('y')->value];?>
</a><br/>
						<?php }} ?>
					<?php }?>
				</td>
				
				<td>
					<?php if (isset($_smarty_tpl->getVariable('info',null,true,false)->value[$_smarty_tpl->getVariable('x',null,true,false)->value]['uniqueidentifier'])){?>
						<?php $_smarty_tpl->tpl_vars['y'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['y']->step = 1;$_smarty_tpl->tpl_vars['y']->total = (int)ceil(($_smarty_tpl->tpl_vars['y']->step > 0 ? $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uniqueidentifier']['count']-1+1 - (0) : 0-($_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uniqueidentifier']['count']-1)+1)/abs($_smarty_tpl->tpl_vars['y']->step));
if ($_smarty_tpl->tpl_vars['y']->total > 0){
for ($_smarty_tpl->tpl_vars['y']->value = 0, $_smarty_tpl->tpl_vars['y']->iteration = 1;$_smarty_tpl->tpl_vars['y']->iteration <= $_smarty_tpl->tpl_vars['y']->total;$_smarty_tpl->tpl_vars['y']->value += $_smarty_tpl->tpl_vars['y']->step, $_smarty_tpl->tpl_vars['y']->iteration++){
$_smarty_tpl->tpl_vars['y']->first = $_smarty_tpl->tpl_vars['y']->iteration == 1;$_smarty_tpl->tpl_vars['y']->last = $_smarty_tpl->tpl_vars['y']->iteration == $_smarty_tpl->tpl_vars['y']->total;?>
							<a href='/user/info/<?php echo $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uniqueidentifier'][$_smarty_tpl->getVariable('y')->value];?>
'><?php echo $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['uniqueidentifier'][$_smarty_tpl->getVariable('y')->value];?>
</a><br/>
						<?php }} ?>
					<?php }?>
				</td>
				
				<td>
					<?php if (isset($_smarty_tpl->getVariable('info',null,true,false)->value[$_smarty_tpl->getVariable('x',null,true,false)->value]['cn'])){?>
						<?php echo $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['cn'][0];?>

					<?php }?>
				</td>
				
				<td>
					<?php if (isset($_smarty_tpl->getVariable('info',null,true,false)->value[$_smarty_tpl->getVariable('x',null,true,false)->value]['globalid'])){?>
						<?php $_smarty_tpl->tpl_vars['y'] = new Smarty_Variable;$_smarty_tpl->tpl_vars['y']->step = 1;$_smarty_tpl->tpl_vars['y']->total = (int)ceil(($_smarty_tpl->tpl_vars['y']->step > 0 ? $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['globalid']['count']-1+1 - (0) : 0-($_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['globalid']['count']-1)+1)/abs($_smarty_tpl->tpl_vars['y']->step));
if ($_smarty_tpl->tpl_vars['y']->total > 0){
for ($_smarty_tpl->tpl_vars['y']->value = 0, $_smarty_tpl->tpl_vars['y']->iteration = 1;$_smarty_tpl->tpl_vars['y']->iteration <= $_smarty_tpl->tpl_vars['y']->total;$_smarty_tpl->tpl_vars['y']->value += $_smarty_tpl->tpl_vars['y']->step, $_smarty_tpl->tpl_vars['y']->iteration++){
$_smarty_tpl->tpl_vars['y']->first = $_smarty_tpl->tpl_vars['y']->iteration == 1;$_smarty_tpl->tpl_vars['y']->last = $_smarty_tpl->tpl_vars['y']->iteration == $_smarty_tpl->tpl_vars['y']->total;?>
							<?php echo $_smarty_tpl->getVariable('info')->value[$_smarty_tpl->getVariable('x')->value]['globalid'][$_smarty_tpl->getVariable('y')->value];?>
<br/>
						<?php }} ?>
					<?php }?>
				</td>
			</tr>
		<?php }} ?>
		</tbody>
	</table>
<?php }?>