<?php /* Smarty version Smarty-3.0.6, created on 2011-04-12 22:28:22
         compiled from "/itcc-dashboard/application/views\searchBlackboard.tpl" */ ?>
<?php /*%%SmartyHeaderCode:40914da54286cd8c93-10681735%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '762a9bffa59b1ec22dd205173fcfd30a732a7c8f' => 
    array (
      0 => '/itcc-dashboard/application/views\\searchBlackboard.tpl',
      1 => 1297459560,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '40914da54286cd8c93-10681735',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_escape')) include 'C:\php\includes\Smarty\plugins\modifier.escape.php';
if (!is_callable('smarty_modifier_truncate')) include 'C:\php\includes\Smarty\plugins\modifier.truncate.php';
?><?php if (count($_smarty_tpl->getVariable('info')->value)==0){?>No results.
<?php }else{ ?>
	<table class='searchResults striped'>
		<thead>
			<tr>
				<th>CRN</th>
				<th>Course Name</th>
				<th>Description</th>
				<th>Active</th>
			</tr>
		<tbody>
		<?php  $_smarty_tpl->tpl_vars['item'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('info')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['item']->key => $_smarty_tpl->tpl_vars['item']->value){
?>
			<tr style=''>
				<td>
					<?php if (isset($_smarty_tpl->getVariable('item',null,true,false)->value->course_id)){?>
						<a href='/course/info/<?php echo smarty_modifier_escape($_smarty_tpl->getVariable('item')->value->pk1,"url");?>
'><?php echo $_smarty_tpl->getVariable('item')->value->course_id;?>
</a>
					<?php }?>
				</td>
				<td>
					<?php if (isset($_smarty_tpl->getVariable('item',null,true,false)->value->course_name)){?>
						<?php echo $_smarty_tpl->getVariable('item')->value->course_name;?>

					<?php }?>
				</td>
				<td>
					<?php if (isset($_smarty_tpl->getVariable('item',null,true,false)->value->course_desc)){?>
						<?php echo smarty_modifier_truncate($_smarty_tpl->getVariable('item')->value->course_desc);?>

					<?php }?>
				</td>
				<td class='centered'>
					<div class='checkbox <?php if ($_smarty_tpl->getVariable('item')->value->row_status==0){?>checked<?php }elseif($_smarty_tpl->getVariable('item')->value->row_status!=2){?>unknown<?php }?>'></div>
				</td>
			</tr>
		<?php }} ?>
		</tbody>
	</table>
<?php }?>