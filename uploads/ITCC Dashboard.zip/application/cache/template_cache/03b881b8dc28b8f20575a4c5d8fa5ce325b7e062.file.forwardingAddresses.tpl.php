<?php /* Smarty version Smarty-3.0.6, created on 2011-04-22 13:07:44
         compiled from "C:\itcc-dashboard\modules\ForwardingAddresses\forwardingAddresses.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10864da5565601ad43-86038231%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '03b881b8dc28b8f20575a4c5d8fa5ce325b7e062' => 
    array (
      0 => 'C:\\itcc-dashboard\\modules\\ForwardingAddresses\\forwardingAddresses.tpl',
      1 => 1302208095,
      2 => 'file',
    ),
    '7d3d1c6c9c86875a7773ab1f9deeac064c26956d' => 
    array (
      0 => '/itcc-dashboard/application/views\\base.tpl',
      1 => 1303237092,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10864da5565601ad43-86038231',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (!is_callable('smarty_modifier_capitalize')) include 'C:\php\includes\Smarty\plugins\modifier.capitalize.php';
if (!is_callable('smarty_modifier_escape')) include 'C:\php\includes\Smarty\plugins\modifier.escape.php';
?><?php if (@ENVIRONMENT=='development'){?>

<!-- ActiveObject Contents:
<?php echo (($tmp = @print_r($_smarty_tpl->getVariable('ao')->value))===null||$tmp==='' ? '' : $tmp);?>

-->
<?php }?>
<!DOCTYPE html>
<html>
<!-- Content Copyright University of Alaska at Anchorage -->
<head>
	<meta name="Description" id="Description" content="IT Services Call Center Dashboard" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="Keywords" id="Keywords" content="" />
	
	<!-- Javascript Libraries -->
	<script type="text/javascript" src="/javascript/jquery-1.5.min.js"></script>
	<!-- Custom jQuery UI containing Draggable, Resizable, Sortable and Dialog components -->
	<script type="text/javascript" src="/javascript/jquery-ui-1.8.7.custom.min.js"></script>

		
	<script type="text/javascript" src="/javascript/uaa.js"></script>
	<!--<script type="text/javascript" src="/javascript/DenaliView.js"></script>-->


	<!-- Stylesheets -->
	<link type="text/css" rel="stylesheet" href="/style/DenaliView.css" />
	<link type="text/css" rel="stylesheet" media="print" href="/style/print.css" />
	<link rel="stylesheet" href="/javascript/jsTree/theme/style.css" />
	<!-- Custom jQuery UI containing CSS for all components -->
	<link rel="stylesheet" href="/javascript/jquery-ui-1.8.7.custom.css" />
	<!--[if lte IE 8]>
	<link type="text/css" rel="stylesheet" href="/style/ie.css" />
	<![endif]-->
	<!--[if lte IE 6]>
	<link type="text/css" rel="stylesheet" href="/style/ie6.css" />
	<![endif]-->
	
	<title> IT Services Call Center Dashboard - University of Alaska Anchorage</title>
	<link type='text/css' rel='stylesheet' href='/style/style.css' />
	<script type='text/javascript' src='/javascript/ITCC.js'></script>
	
</head>
<body class=''>
	<?php if (@ENVIRONMENT!='production'){?><span style='position: absolute; z-index: 1000; left: 0; top: 0; text-align: center; background-color: red; background-color: rgba(255, 0, 0, 0.6); color: white; font-weight: bold; padding: 5px 20px;'>NOTE: Currently running in <?php echo ((mb_detect_encoding(@ENVIRONMENT, 'UTF-8, ISO-8859-1') === 'UTF-8') ? mb_strtoupper(@ENVIRONMENT,SMARTY_RESOURCE_CHAR_SET) : strtoupper(@ENVIRONMENT));?>
 mode</span><?php }?>
	<div id="header">
		<div class='frame'>
			<div id="topnav">
				<div><a href="#content">Skip Navigation</a> | <a href="http://www.uaa.alaska.edu/map/">Campus Map</a> | <a href="http://www.uaa.alaska.edu/atoz/">A to Z</a> | <a href="http://www.uaa.alaska.edu/directory.cfm">Directory</a></div>
				<?php if (isset($_smarty_tpl->getVariable('activeObject',null,true,false)->value)){?>
				<div id='activeObject'>
					<a href='<?php echo $_smarty_tpl->getVariable('activeObject')->value->url;?>
'>
						<div class='info'>
							<div class='name'><?php echo (($tmp = @$_smarty_tpl->getVariable('activeObject')->value->name)===null||$tmp==='' ? '' : $tmp);?>
</div>
							<?php $_tmp1=ActiveObject::USER;?><?php if ($_smarty_tpl->getVariable('activeObject')->value instanceof $_tmp1){?>
								<div class='UAID'><?php echo (($tmp = @$_smarty_tpl->getVariable('activeObject')->value->id)===null||$tmp==='' ? '' : $tmp);?>
</div>
								<div class='UID'><?php echo (($tmp = @$_smarty_tpl->getVariable('activeObject')->value->uid)===null||$tmp==='' ? '' : $tmp);?>
</div>
							<?php }else{?><?php $_tmp2=ActiveObject::COURSE;?><?php if ($_smarty_tpl->getVariable('activeObject')->value instanceof $_tmp2){?>
								<div class='UID'><?php echo (($tmp = @$_smarty_tpl->getVariable('activeObject')->value->crn)===null||$tmp==='' ? '' : $tmp);?>
</div>
							<?php }}?>
						</div>
						<img class='image' src='<?php echo $_smarty_tpl->getVariable('activeObject')->value->IMG_SRC;?>
' alt='' />
					</a>
				</div>
				<?php }?>
			</div>
			<div id="logo">
				<a href="/"><img src='/images/ITS.jpg' alt='University of Alaska Anchorage IT Services' /></a>
			</div>
			<div class='clear'></div>
		</div>
	</div>

	<div class='frame glow'>
		<div id="main">
			<div id="topbar">
				<form action="/search/" method="post" id="search">
					<select id="searchFilter" name='filter'>
						<option value=''>Search</option>
						<optgroup label='User Accounts'>
							<option <?php if (isset($_smarty_tpl->getVariable('filter',null,true,false)->value)&&$_smarty_tpl->getVariable('filter')->value=='uaid'){?>SELECTED<?php }?> value='uaid'>UA ID</option>
							<option <?php if (isset($_smarty_tpl->getVariable('filter',null,true,false)->value)&&$_smarty_tpl->getVariable('filter')->value=='username'){?>SELECTED<?php }?> value='username'>Username</option>
							<option <?php if (isset($_smarty_tpl->getVariable('filter',null,true,false)->value)&&$_smarty_tpl->getVariable('filter')->value=='name'){?>SELECTED<?php }?> value='name'>First/Last Name</option>
						</optgroup>
						<optgroup label='Classes'>
							<option <?php if (isset($_smarty_tpl->getVariable('filter',null,true,false)->value)&&$_smarty_tpl->getVariable('filter')->value=='crn'){?>SELECTED<?php }?> value='crn'>CRN</option>
							<option <?php if (isset($_smarty_tpl->getVariable('filter',null,true,false)->value)&&$_smarty_tpl->getVariable('filter')->value=='description'){?>SELECTED<?php }?> value='description'>Class Description</option>
							<option <?php if (isset($_smarty_tpl->getVariable('filter',null,true,false)->value)&&$_smarty_tpl->getVariable('filter')->value=='instructor'){?>SELECTED<?php }?> value='instructor'>Instructor</option>
						</optgroup>
					</select>
					<input type="search" id="searchQ" name='search' value='<?php echo (($tmp = @$_smarty_tpl->getVariable('search')->value)===null||$tmp==='' ? '' : $tmp);?>
' />
				</form>
				<div id="breadcrumb">
					<a href='http://callcenter.uaa.alaska.edu/'>IT Services Call Center</a> <span>&gt;</span>
					<?php if (count($_smarty_tpl->getVariable('breadcrumbs')->value)==0){?>
						<span>Dashboard</span>
					<?php }else{ ?>
						<a href='/'>Dashboard</a> <span>&gt;</span>
						<?php  $_smarty_tpl->tpl_vars['breadcrumb'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('breadcrumbs')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
 $_smarty_tpl->tpl_vars['breadcrumb']->total= $_smarty_tpl->_count($_from);
 $_smarty_tpl->tpl_vars['breadcrumb']->iteration=0;
if ($_smarty_tpl->tpl_vars['breadcrumb']->total > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['breadcrumb']->key => $_smarty_tpl->tpl_vars['breadcrumb']->value){
 $_smarty_tpl->tpl_vars['breadcrumb']->iteration++;
 $_smarty_tpl->tpl_vars['breadcrumb']->last = $_smarty_tpl->tpl_vars['breadcrumb']->iteration === $_smarty_tpl->tpl_vars['breadcrumb']->total;
?>
							<?php if (!$_smarty_tpl->tpl_vars['breadcrumb']->last){?>
								<a href='<?php echo $_smarty_tpl->tpl_vars['breadcrumb']->value['url'];?>
'><?php echo smarty_modifier_capitalize($_smarty_tpl->tpl_vars['breadcrumb']->value['name']);?>
</a> <span>&gt;</span>
							<?php }else{ ?>
								<span><?php echo smarty_modifier_capitalize($_smarty_tpl->tpl_vars['breadcrumb']->value['name']);?>
</span>
							<?php }?>
						<?php }} ?>
					<?php }?>
				</div>
				<div class='clear'></div>
			</div>
			
			<!-- Display Splash Image -->
			<div id="splash">
			</div>
			<div id="sidebar" class='aside'>
				<div id="leftnav" class='nav jstree jstree-0'>
					<ul>
						<li><a href="/">Dashboard</a>
							<ul>
							<?php  $_smarty_tpl->tpl_vars['modules'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['category'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('leftnav')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['modules']->key => $_smarty_tpl->tpl_vars['modules']->value){
 $_smarty_tpl->tpl_vars['category']->value = $_smarty_tpl->tpl_vars['modules']->key;
?>
								<?php if ($_smarty_tpl->tpl_vars['category']->value!='Uncategorized'){?>
								<li><a href=''><?php echo $_smarty_tpl->tpl_vars['category']->value;?>
</a>
									<ul>
										<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['modules']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
?>
										<li><a href='<?php echo (($tmp = @$_smarty_tpl->tpl_vars['module']->value['url'])===null||$tmp==='' ? "/pageNotFound/" : $tmp);?>
'><?php echo (($tmp = @$_smarty_tpl->tpl_vars['module']->value['name'])===null||$tmp==='' ? "Invalid Name" : $tmp);?>
</a></li>
										<?php }} ?>
									</ul>
								</li>
								<?php }?>
							<?php }} ?>
							<?php if (isset($_smarty_tpl->getVariable('leftnav',null,true,false)->value['Uncategorized'])){?>
								<?php  $_smarty_tpl->tpl_vars['module'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['moduleName'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('leftnav')->value['Uncategorized']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['module']->key => $_smarty_tpl->tpl_vars['module']->value){
 $_smarty_tpl->tpl_vars['moduleName']->value = $_smarty_tpl->tpl_vars['module']->key;
?>
									<li><a href='<?php echo $_smarty_tpl->getVariable('modules')->value['url'];?>
'><?php echo $_smarty_tpl->getVariable('modules')->value['name'];?>
</a></li>
								<?php }} ?>
							<?php }?>
								<li><a href='/module/'>Administration</a></li>
								<li><a href='/logentries/'>Log</a></li>
							</ul>
						</li>
					</ul>
				</div>
				
			</div>
			
			
			<div id="content">
<h1>Forwarding Addresses</h1>

<form action='/module/load/ForwardingAddresses/newAddress' method='POST'>
	<fieldset>
		<legend>New Adress</legend>
		<p><label for='newAdress'>E-mail: </label><input name='newAddress' value='' autofocus /></p>
		<input type='submit' value='Add Forwarding Address' />
	</fieldset>
</form>
<br/>

<?php if (isset($_smarty_tpl->getVariable('forwardingaddresses',null,true,false)->value)){?>
	<table>
		<thead>
			<tr>
				<th></th>
				<th>E-mail Address</th>
			</tr>
		</thead>
		<tbody>
		<?php  $_smarty_tpl->tpl_vars['address'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('forwardingaddresses')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['address']->key => $_smarty_tpl->tpl_vars['address']->value){
?>
			<tr>
				<td><a href='/module/load/ForwardingAddresses/removeAddress/<?php echo smarty_modifier_escape($_smarty_tpl->tpl_vars['address']->value,'url');?>
'><img alt="Remove" src="/images/silk_icons/delete.png" /></a></td>
				<td><a href='<?php echo $_smarty_tpl->tpl_vars['address']->value;?>
'><?php echo $_smarty_tpl->tpl_vars['address']->value;?>
</a></td>
			</tr>
		<?php }} else { ?><tr><td colspan=2>No addresses present</td></tr>
		<?php } ?>
		</tbody>
	</table>
<?php }?>

</div>
			<div class="clear"><!-- Clearing Floats --></div>
		</div>
			
		<div id="footer" class="footer">
			<div class='column first'>
				<ul>
					<li class="header" style='list-style-image: url("/images/fugue_icons/icons/globe-medium-green.png");'><a >Gateways</a></li>
					<li><a href='http://www.uaa.alaska.edu/students/'>Current Students</a></li>
					<li><a href='http://www.uaa.alaska.edu/futurestudents/'>Future Students</a></li>
					<li><a href='http://www.uaa.alaska.edu/faculty/'>Faculty</a></li>
					<li><a href='http://www.uaa.alaska.edu/staff/'>Staff</a></li>
					<li><a href='http://www.uaa.alaska.edu/alumni/'>Alumni</a></li>
					<li><br/></li>
					<li><a href='http://www.uaa.alaska.edu/classes/'>Blackboard</a></li>
					<li><a href='http://www.uaa.alaska.edu/calendar/'>Calendar</a></li>
					<li><a href='http://www.uaa.alaska.edu/emergency/'>Emergency Information</a></li>
					<li><a href='https://webaccess.uaa.alaska.edu/'>Faculty/Staff Email</a></li>
					<li><a href='http://www.uaa.alaska.edu/financialaid/'>Financial Aid</a></li>
					<li><a href='http://www.uaa.alaska.edu/parents/'>Parents</a></li>
					<li><a href='http://webmail.uaa.alaska.edu/'>Student Email</a></li>
					<li><a href='http://uaonline.alaska.edu/'>UA Online</a></li>
				</ul>
			</div>
			
			<div class='column'>
				<ul>
					<li class="header" style='list-style-image: url("/images/fugue_icons/icons/question-white.png");'><a href='http://www.uaa.alaska.edu/aboutuaa/'>About UAA</a></li>
					<li><a href='http://www.uaa.alaska.edu/accessibility/'>Accessibility</a></li>
					<li><a href='http://www.uaa.alaska.edu/administration/'>Administration</a></li>
					<li><a href='http://www.uaa.alaska.edu/chancellor/'>Chancellor's Office</a></li>
					<li><a href='http://www.uaa.alaska.edu/campuses/'>Community Campuses</a></li>
					<li><a href='http://www.uaa.alaska.edu/diversity/diversity/choices.cfm'>Diversity Resources</a></li>
					<li><a href='http://www.uaa.alaska.edu/humanresources/employment/'>Employment</a></li>
					<li><a href='http://www.uaa.alaska.edu/map'>Map</a></li>
					<li><a href='http://www.uaa.alaska.edu/chancellor/uaa-mission-statement.cfm'>Mission</a></li>
					<li><a href='http://www.uaa.alaska.edu/news/'>News and Publications</a></li>
					<li><a href='http://www.uaa.alaska.edu/strategicplan/'>Strategic Plan</a></li>
				</ul>
			</div>
			
			<div class='column'>
				<ul>
					<li class="header" style='list-style-image: url("/images/fugue_icons/icons/books.png");'><a href='http://www.uaa.alaska.edu/academics/'>Academics</a></li>
					<li><a href='http://www.uaa.alaska.edu/records/calendar.cfm'>Academic Calendar</a></li>
					<li><a href='http://www.uaa.alaska.edu/admissions/'>Admissions</a></li>
					<li><a href='http://www.uaa.alaska.edu/advising-testing/'>Advising and Testing</a></li>  
					<li><a href='http://www.uaa.alaska.edu/records/catalogs/catalogs.cfm'>Catalog</a></li>
					<li><a href='http://www.uaa.alaska.edu/records/catalogs/schedules.cfm'>Class Schedule</a></li>
					<li><a href='http://www.uaa.alaska.edu/academics/colleges.cfm'>Colleges and Schools</a></li>
					<li><a href='http://www.uaa.alaska.edu/computerlabs/'>Computer Labs</a></li>					
					<li><a href='http://lib.uaa.alaska.edu/'>Consortium Library</a></li>
					<li><a href='http://www.uaa.alaska.edu/distanceeducation/'>Distance Education</a></li>
					<li><a href='http://www.uaa.alaska.edu/financialaid/'>Financial Aid</a></li>
					<li><a href='http://www.uaa.alaska.edu/onestop/'>One Stop</a></li>
					<li><a href='http://www.uaa.alaska.edu/records/'>Registration/Registrar</a></li>
				</ul>
			</div>
			
			<div class='column'>

				<ul>
					<li class="header" style='list-style-image: url("/images/fugue_icons/icons/flask--pencil.png");'><a href='http://www.uaa.alaska.edu/research/'>Research</a></li>
					<li><a href='http://www.uaa.alaska.edu/academics/research/'>Centers and Institutes</a></li>
					<li><a href='http://www.uaa.alaska.edu/academics/colleges.cfm'>Schools and Colleges</a></li>
					<li><a href='http://www.uaa.alaska.edu/ours/'>Undergraduate Research</a></li>
				</ul>
			</div>

			
			<div class='column'>
				<ul>
					<li class="header" style='list-style-image: url("/images/fugue_icons/icons/cup.png");'><a >Campus Life</a></li>
					<li><a href='http://www.uaa.alaska.edu/athletics/'>Athletics</a></li>
					<li><a href='http://www.uaa.alaska.edu/calendar/'>Calendar</a></li>
					<li><a href='http://www.uaa.alaska.edu/bookstore/'>Bookstore</a></li>
					<li><a href='http://www.uaa.alaska.edu/studentunionandcommuterstudentservices/commuterstudentservices/'>Commuter Student Services</a></li>
					<li><a href='http://www.uaa.alaska.edu/recreation/intramurals/'>Intramural Sports</a></li>
					<li><a href='http://www.uaa.alaska.edu/nss/'>Native Student Services</a></li>
					<li><a href='http://www.uaa.alaska.edu/parking/'>Parking Services</a></li>
					<li><a href='http://www.uaa.alaska.edu/residencelife/'>Residence Life</a></li>
					<li><a href='http://www.uaa.alaska.edu/studentlife/'>Student Life</a></li>
					<li><a href='http://www.uaa.alaska.edu/sll/media/'>Student Media</a></li>
					<li><a href='http://www.uaa.alaska.edu/unionofstudents/'>USUAA Student Government</a></li>	
					<li><a href='http://www.uaa.alaska.edu/recreation/sports-complex/'>Wells Fargo Sports Complex</a></li>
				</ul>
			</div>
			
			<div class='column'>
				<ul>
					<li class="header" style='list-style-image: url("/images/fugue_icons/icons/balloon-quotation.png");'><a >Public Square</a></li>
					<li><a href='http://www.uaa.alaska.edu/athletics/'>Athletics</a></li>
					<li><a href='http://www.uaa.alaska.edu/calendar/'>Calendar</a></li>
					<li><a href='http://lib.uaa.alaska.edu/'>Consortium Library</a></li>
					<li><a href='http://www.uaa.alaska.edu/giving/'>Giving to UAA</a></li>
					<li><a href='http://www.uaa.alaska.edu/news/'>News and Publications</a></li>
					<li><a href='http://greenandgold.uaa.alaska.edu/podcasts'>Podcasts</a></li>
					<li><a href='http://www.uaa.alaska.edu/visiting/'>Visiting the Campus</a></li>
					<li><a href='http://www.uaa.alaska.edu/recreation/sports-complex/'>Wells Fargo Sports Complex</a></li>
					<li><a href='http://www.uaa.alaska.edu/wwa/'>Wendy Williamson Auditorium</a></li>
				</ul>
				
			</div>
			
			<div class='column last'>
				<ul>
					<li class="header" style='list-style-image: url("/images/fugue_icons/icons/computer.png");'><a href='http://www.uaa.alaska.edu/informationtechnologyservices/'>IT Services</a></li>

					<li><a href='https://callcenter.uaa.alaska.edu'>Call Center</a></li>
					<li><a href='http://kb.uaa.alaska.edu'>Knowledge Base</a></li>
					<li><a href='https://anc-its.uaa.alaska.edu/'>Sharepoint</a></li>
					<li><a href='http://www.uaa.alaska.edu/webpublishing/'>Web Publishing</a></li>
				</ul>
			</div>
			
			<div id="footerinfo">
				<div id="bottomnav">
					<div><a href='http://www.uaa.alaska.edu/aboutuaa/index.cfm'>About UAA</a>  |  <a href='http://www.uaa.alaska.edu/contact.cfm'>Contact UAA</a>  |  <a href='http://www.alaska.edu/'>University of Alaska System</a>  | <a href='http://www.uaa.alaska.edu/policy/index.cfm'>Use Policy</a></div>
					<div><a href="mailto:web_team@uaa.alaska.edu"><img src='/images/silk_icons/comment.png' alt='' style='vertical-align: middle;' /> Provide Website Feedback</a></div>
					<div>
						<img src="/images/silk_icons/xhtml_valid.png" alt="Valid XHTML" style='vertical-align: middle;' />
						<a href="/module/" id='footerlogin'><img src="/images/ttt.gif" width="26" height="5" alt="Login" /></a>
					</div>
				</div>
				<a href="http://www.uaa.alaska.edu">&copy; Copyright 2010, University of Alaska Anchorage</a>
				<div>UAA is an EEO/AA employer and educational institution</div>
				<div>Version: <?php echo @VERSION;?>
, <?php echo @REVISION;?>
</div>
			</div>
		</div>
	</div>
	
</body>
</html>