jQuery(function() {
	$("#search").submit(searchSubmit);

});


function searchSubmit(event) {
	var filterValue = jQuery('select', this).val();
	
	//Update hidden submit field
	jQuery('#submitQ').val(jQuery('#searchQ').val());
	
	if(filterValue == "This Site") {
		this.action = "http://www.google.com/cse";
		
		var subsiteRoot = commonspot.csPage.subsiteRoot.split("/");
		if(subsiteRoot.length > 1) subsiteRoot = subsiteRoot[1];
		else subsiteRoot = "";
		
		this.q.value = this.q.value + " site:www.uaa.alaska.edu/" + subsiteRoot;
		
		if(this.cx.value.substr(0, 1) !== "!")
			this.cx.value = "!" + this.cx.value;
	}
	else if(filterValue == "All UAA") {
		this.action = "http://www.google.com/cse";
		this.q.value = this.q.value + " site:uaa.alaska.edu";
		
		if(this.cx.value.substr(0, 1) !== "!")
			this.cx.value = "!" + this.cx.value;
	}
	else if(filterValue == "People") {
		this.action = "/directoryResults.cfm";
		this.q.name = 'criteria';
	}
	else {
		//Default search
		this.action = "http://www.google.com/cse";
		
		if(this.cx.value.substr(0, 1) === "!")
			this.cx.value = this.cx.value.substr(1);
	}
}